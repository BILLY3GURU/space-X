import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';

export default function App() {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar onBookNow={() => setIsBookingModalOpen(true)} />
      <main className="flex-grow">
        <Hero />
        <Services />
        <Gallery />
        <About />
        
        {/* Call to Action Section */}
        <section className="py-24 px-6 bg-brand-dark text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
             <img 
               src="https://images.unsplash.com/photo-1512690196252-751d3948f4ed?auto=format&fit=crop&q=80&w=2000" 
               alt="Background" 
               className="w-full h-full object-cover"
               referrerPolicy="no-referrer"
             />
          </div>
          <div className="max-w-4xl mx-auto relative z-10">
            <h2 className="text-4xl md:text-7xl font-serif font-bold mb-8 leading-tight">
              Ready to Experience <br />
              <span className="italic text-brand-pink">The Space X Standard?</span>
            </h2>
            <p className="text-white/60 text-lg md:text-xl mb-12 font-light max-w-2xl mx-auto">
              Join our exclusive community and transform your daily routine into a series of premium moments.
            </p>
            <button 
              onClick={() => setIsBookingModalOpen(true)}
              className="inline-block px-12 py-5 bg-brand-teal text-white font-bold uppercase tracking-widest text-sm hover:bg-brand-pink transition-all duration-300"
            >
              Book Your Appointment
            </button>
          </div>
        </section>
      </main>
      <Footer />
      <BookingModal 
        isOpen={isBookingModalOpen} 
        onClose={() => setIsBookingModalOpen(false)} 
      />
    </div>
  );
}
