import React from 'react';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-brand-dark text-white pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="space-y-8">
            <a href="#" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-brand-gold rounded-full flex items-center justify-center text-white font-serif text-xl font-bold">
                S
              </div>
              <span className="text-2xl font-serif font-bold tracking-tight">
                SPACE X
              </span>
            </a>
            <p className="text-white/50 font-light leading-relaxed">
              Redefining the lifestyle experience through precision, passion, and unparalleled service quality.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-gold hover:border-brand-gold transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-gold hover:border-brand-gold transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-gold hover:border-brand-gold transition-all">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-8 text-brand-pink">Services</h4>
            <ul className="space-y-4 text-white/60 font-light text-sm">
              <li><a href="#" className="hover:text-brand-teal transition-colors">Kinyozi & Grooming</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Massage Therapy</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Pool & Entertainment</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Live Sports Lounge</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Saloon & Nails</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Premium Laundry</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-8 text-brand-pink">Company</h4>
            <ul className="space-y-4 text-white/60 font-light text-sm">
              <li><a href="#" className="hover:text-brand-teal transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Our Team</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-brand-teal transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-8 text-brand-pink">Contact</h4>
            <ul className="space-y-6 text-white/60 font-light text-sm">
              <li className="flex gap-4">
                <MapPin className="w-5 h-5 text-brand-teal shrink-0" />
                <span>123 Luxury Avenue, <br />Eldoret, Kenya</span>
              </li>
              <li className="flex gap-4">
                <Phone className="w-5 h-5 text-brand-teal shrink-0" />
                <span>+254 700 000 000</span>
              </li>
              <li className="flex gap-4">
                <Mail className="w-5 h-5 text-brand-teal shrink-0" />
                <span>hello@spacexlifestyle.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-white/30 text-xs font-light">
            © 2026 Space X Lifestyle. All rights reserved.
          </p>
          <p className="text-white/30 text-xs font-light italic">
            Designed for Excellence.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
