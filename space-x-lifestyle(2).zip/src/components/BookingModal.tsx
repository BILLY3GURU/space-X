import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, User, Mail, Phone, ChevronRight } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const services = [
    "Kinyozi (Barber)",
    "Massage Therapy",
    "Pool Table Games",
    "Saloon & Nails",
    "Laundry Services"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we would handle the form submission here
    alert("Thank you! Your booking request has been received. We will contact you shortly.");
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-brand-indigo/95 backdrop-blur-md"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-white text-brand-dark overflow-hidden shadow-2xl rounded-2xl"
          >
            <button 
              onClick={onClose}
              className="absolute top-6 right-6 z-20 text-brand-dark/40 hover:text-brand-pink transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="p-8 md:p-12">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-brand-gold rounded-full flex items-center justify-center text-white">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-3xl font-serif font-bold leading-tight">Book Your Experience</h2>
                  <p className="text-brand-dark/60 text-sm font-light">Fill in the details below to schedule your visit.</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-dark/40 flex items-center gap-2">
                      <User className="w-3 h-3" /> Full Name
                    </label>
                    <input 
                      required
                      type="text" 
                      placeholder="John Doe"
                      className="w-full px-4 py-3 bg-brand-light border border-black/5 focus:border-brand-gold outline-none transition-colors rounded-lg font-light"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-dark/40 flex items-center gap-2">
                      <Mail className="w-3 h-3" /> Email Address
                    </label>
                    <input 
                      required
                      type="email" 
                      placeholder="john@example.com"
                      className="w-full px-4 py-3 bg-brand-light border border-black/5 focus:border-brand-gold outline-none transition-colors rounded-lg font-light"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-dark/40 flex items-center gap-2">
                      <Phone className="w-3 h-3" /> Phone Number
                    </label>
                    <input 
                      required
                      type="tel" 
                      placeholder="+254 700 000 000"
                      className="w-full px-4 py-3 bg-brand-light border border-black/5 focus:border-brand-gold outline-none transition-colors rounded-lg font-light"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-dark/40 flex items-center gap-2">
                      <Calendar className="w-3 h-3" /> Service Preference
                    </label>
                    <select 
                      required
                      className="w-full px-4 py-3 bg-brand-light border border-black/5 focus:border-brand-gold outline-none transition-colors rounded-lg font-light appearance-none cursor-pointer"
                    >
                      <option value="">Select a service</option>
                      {services.map(service => (
                        <option key={service} value={service}>{service}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-brand-indigo text-white font-bold uppercase tracking-widest text-sm hover:bg-brand-pink transition-all duration-300 flex items-center justify-center gap-2 group rounded-lg mt-4"
                >
                  Confirm Booking Request
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </form>

              <p className="text-center text-xs text-brand-dark/40 mt-8 font-light">
                By booking, you agree to our terms of service and privacy policy.
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default BookingModal;
