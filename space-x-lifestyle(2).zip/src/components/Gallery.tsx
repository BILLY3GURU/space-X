import React, { useState } from 'react';
import Lightbox from 'react-image-lightbox';
import 'react-image-lightbox/style.css';
import { motion } from 'motion/react';
import { Maximize2, Plus } from 'lucide-react';

const images = [
  {
    url: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&q=80&w=1200",
    title: "The Kinyozi Station",
    category: "Barber"
  },
  {
    url: "https://images.unsplash.com/photo-1544161515-4af6b1d462c2?auto=format&fit=crop&q=80&w=1200",
    title: "Massage Sanctuary",
    category: "Wellness"
  },
  {
    url: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80&w=1200",
    title: "Pool Lounge",
    category: "Entertainment"
  },
  {
    url: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1200",
    title: "Sports Arena",
    category: "Entertainment"
  },
  {
    url: "https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&q=80&w=1200",
    title: "Nail Studio",
    category: "Salon"
  },
  {
    url: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&q=80&w=1200",
    title: "Premium Laundry",
    category: "Service"
  },
  {
    url: "https://images.unsplash.com/photo-1512690196252-751d3948f4ed?auto=format&fit=crop&q=80&w=1200",
    title: "The Lounge",
    category: "Interior"
  },
  {
    url: "https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&q=80&w=1200",
    title: "Detailing Area",
    category: "Service"
  }
];

const Gallery = () => {
  const [photoIndex, setPhotoIndex] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <section id="gallery" className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-brand-pink font-bold tracking-widest uppercase text-xs mb-4 block">
            Visual Tour
          </span>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-brand-dark leading-tight mb-6">
            Our <span className="italic text-brand-gold">Space</span>
          </h2>
          <p className="text-brand-dark/60 max-w-2xl mx-auto text-lg font-light">
            Step inside our world. A meticulously designed environment where luxury meets comfort in every corner.
          </p>
        </div>

        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              viewport={{ once: true }}
              className="relative group cursor-pointer overflow-hidden rounded-2xl break-inside-avoid"
              onClick={() => {
                setPhotoIndex(index);
                setIsOpen(true);
              }}
            >
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-brand-indigo/60 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mb-4 transform scale-50 group-hover:scale-100 transition-transform duration-500">
                  <Plus className="text-white w-6 h-6" />
                </div>
                <span className="text-brand-teal text-xs font-bold uppercase tracking-widest mb-2">
                  {image.category}
                </span>
                <h3 className="text-white text-xl font-serif font-bold">
                  {image.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {isOpen && (
        <Lightbox
          mainSrc={images[photoIndex].url}
          nextSrc={images[(photoIndex + 1) % images.length].url}
          prevSrc={images[(photoIndex + images.length - 1) % images.length].url}
          onCloseRequest={() => setIsOpen(false)}
          onMovePrevRequest={() =>
            setPhotoIndex((photoIndex + images.length - 1) % images.length)
          }
          onMoveNextRequest={() =>
            setPhotoIndex((photoIndex + 1) % images.length)
          }
          imageTitle={images[photoIndex].title}
          imageCaption={images[photoIndex].category}
          reactModalStyle={{
            overlay: {
              zIndex: 2000,
              backgroundColor: 'rgba(10, 10, 10, 0.95)',
              backdropFilter: 'blur(10px)'
            }
          }}
        />
      )}
    </section>
  );
};

export default Gallery;
