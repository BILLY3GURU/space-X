import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Scissors, Heart, Tv, Beer, Sparkles, Shirt, X } from 'lucide-react';

interface Service {
  title: string;
  description: string;
  image: string;
  icon: React.ReactNode;
}

const services: Service[] = [
  {
    title: "Kinyozi",
    description: "Precision grooming and traditional shaves for the modern gentleman. Our expert barbers use the finest techniques and products to ensure you leave looking and feeling your absolute best.",
    image: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&q=80&w=1200",
    icon: <Scissors className="w-6 h-6" />
  },
  {
    title: "Massage",
    description: "Therapeutic treatments designed to melt away stress and tension. From deep tissue to Swedish massage, our professional therapists tailor each session to your specific needs.",
    image: "https://images.unsplash.com/photo-1544161515-4af6b1d462c2?auto=format&fit=crop&q=80&w=1200",
    icon: <Heart className="w-6 h-6" />
  },
  {
    title: "Pool Table Games",
    description: "Professional grade tables for competitive or casual play. Enjoy a game in our sophisticated lounge area, perfect for unwinding with friends or colleagues.",
    image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80&w=1200",
    icon: <Beer className="w-6 h-6" />
  },
  {
    title: "Live Sports",
    description: "Catch every game in high definition with premium surround sound. Our sports lounge offers the ultimate viewing experience for all major sporting events.",
    image: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1200",
    icon: <Tv className="w-6 h-6" />
  },
  {
    title: "Saloon & Nails",
    description: "Expert styling and nail care for a polished, professional look. We offer a full range of salon services to help you maintain your personal style.",
    image: "https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&q=80&w=1200",
    icon: <Sparkles className="w-6 h-6" />
  },
  {
    title: "Laundry",
    description: "Premium garment care with same-day service availability. We handle your clothing with the utmost care, ensuring everything is returned perfectly cleaned and pressed.",
    image: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&q=80&w=1200",
    icon: <Shirt className="w-6 h-6" />
  }
];

const Services = () => {
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  return (
    <section id="services" className="py-24 px-6 bg-brand-indigo text-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <span className="text-brand-pink font-bold tracking-widest uppercase text-xs mb-4 block">
              Our Expertise
            </span>
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-white leading-tight">
              A Curated Selection of <br />
              <span className="italic text-brand-teal">Premium Services</span>
            </h2>
          </div>
          <p className="text-white/60 max-w-sm text-lg font-light">
            We've brought together the finest professionals to provide a comprehensive lifestyle experience under one roof.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10 border border-white/10">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05, zIndex: 10 }}
              transition={{ 
                delay: index * 0.1,
                scale: { duration: 0.2, ease: "easeOut" }
              }}
              viewport={{ once: true }}
              onClick={() => setSelectedService(service)}
              className="relative overflow-hidden group cursor-pointer aspect-[4/5] bg-brand-indigo border border-transparent hover:border-brand-gold transition-colors duration-300 shadow-xl"
            >
              <img 
                src={service.image} 
                alt={service.title}
                className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:scale-110 group-hover:grayscale-0"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-brand-indigo/40 group-hover:bg-brand-indigo/60 transition-colors duration-500 flex flex-col justify-end p-8">
                <div className="w-12 h-12 bg-brand-pink text-white flex items-center justify-center mb-6">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-serif font-bold text-white mb-2">
                  {service.title}
                </h3>
                <div className="relative overflow-hidden transition-all duration-500 max-h-12 group-hover:max-h-48">
                  <p className="text-white/70 text-sm font-light max-w-xs line-clamp-2 group-hover:line-clamp-none transition-all duration-500">
                    {service.description}
                  </p>
                </div>
                <div className="mt-6 w-8 h-[1px] bg-brand-teal group-hover:w-full transition-all duration-500" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Service Modal */}
      <AnimatePresence>
        {selectedService && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedService(null)}
              className="absolute inset-0 bg-brand-indigo/95 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-5xl bg-white text-brand-dark overflow-hidden shadow-2xl flex flex-col md:flex-row"
            >
              <button 
                onClick={() => setSelectedService(null)}
                className="absolute top-4 right-4 z-20 w-10 h-10 bg-brand-dark text-white flex items-center justify-center hover:bg-brand-pink transition-colors"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="w-full md:w-1/2 aspect-video md:aspect-auto">
                <img 
                  src={selectedService.image} 
                  alt={selectedService.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <div className="w-12 h-12 bg-brand-pink text-white flex items-center justify-center mb-8">
                  {selectedService.icon}
                </div>
                <span className="text-brand-teal font-bold tracking-widest uppercase text-xs mb-4 block">
                  Service Details
                </span>
                <h3 className="text-4xl md:text-5xl font-serif font-bold mb-6">
                  {selectedService.title}
                </h3>
                <p className="text-brand-dark/70 text-lg font-light leading-relaxed mb-10">
                  {selectedService.description}
                </p>
                <button 
                  className="w-full md:w-max px-10 py-4 bg-brand-indigo text-white font-bold uppercase tracking-widest text-sm hover:bg-brand-pink transition-all duration-300"
                  onClick={() => setSelectedService(null)}
                >
                  Close Details
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Services;
