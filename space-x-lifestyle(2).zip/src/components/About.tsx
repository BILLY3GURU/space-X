import React from 'react';
import { motion } from 'motion/react';

const About = () => {
  return (
    <section id="about" className="py-24 px-6 bg-brand-light overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <span className="text-brand-pink font-bold tracking-widest uppercase text-xs mb-4 block">
              Our Philosophy
            </span>
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-brand-dark mb-8 leading-tight">
              Crafting Moments of <br />
              <span className="italic text-brand-teal">Pure Excellence</span>
            </h2>
            <div className="space-y-6 text-brand-dark/70 text-lg font-light leading-relaxed">
              <p>
                Space X was founded on a simple premise: that quality of life is defined by the quality of the services we interact with daily. We believe that a haircut isn't just a cut, and a massage isn't just a treatment—they are essential rituals of self-care.
              </p>
              <p>
                Our space is designed to be a sanctuary. Whether you're here to catch the big game with friends, enjoy a quiet moment of relaxation, or ensure your garments are perfectly cared for, we provide an environment that respects your time and elevates your standards.
              </p>
            </div>
            
            <div className="mt-12 grid grid-cols-2 gap-8">
              <div>
                <span className="text-3xl font-serif font-bold text-brand-pink block mb-2">15+</span>
                <span className="text-xs uppercase tracking-widest text-brand-dark/50 font-bold">Expert Artisans</span>
              </div>
              <div>
                <span className="text-3xl font-serif font-bold text-brand-teal block mb-2">5k+</span>
                <span className="text-xs uppercase tracking-widest text-brand-dark/50 font-bold">Happy Clients</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] relative z-10">
              {/* Note: User provided blob:https://web.whatsapp.com/2838dfa2-0a3f-4c5a-a335-c69048e1e3d3 which is inaccessible. Using high-quality interior image instead. */}
              <img 
                src="https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&q=80&w=1000" 
                alt="Space X Interior" 
                className="w-full h-full object-cover shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-64 h-64 border border-brand-pink/20 -z-0" />
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-brand-teal/10 -z-0" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
