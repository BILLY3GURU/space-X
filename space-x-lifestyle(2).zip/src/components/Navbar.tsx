import React, { useState, useEffect } from 'react';
import { Menu, X, Scissors, Heart, Tv, Beer, Sparkles, Shirt, Waves } from 'lucide-react';
import { cn } from '../lib/utils';

interface NavbarProps {
  onBookNow: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onBookNow }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Services', href: '#services' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={cn(
      "fixed top-0 w-full z-50 transition-all duration-300 px-6 py-4",
      isScrolled ? "glass-nav py-3" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-brand-gold rounded-full flex items-center justify-center text-white font-serif text-xl font-bold group-hover:scale-110 transition-transform">
            S
          </div>
          <span className={cn(
            "text-2xl font-serif font-bold tracking-tight transition-colors flex items-baseline gap-1",
            isScrolled ? "text-brand-dark" : "text-white"
          )}>
            SPACE <span className="text-4xl text-brand-gold">X</span>
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={cn(
                "text-sm font-medium tracking-widest uppercase transition-colors hover:text-brand-gold",
                isScrolled ? "text-brand-dark" : "text-white/90"
              )}
            >
              {link.name}
            </a>
          ))}
          <button 
            onClick={onBookNow}
            className={cn(
              "px-6 py-2 border text-xs font-bold uppercase tracking-widest transition-all",
              isScrolled 
                ? "border-brand-dark text-brand-dark hover:bg-brand-dark hover:text-white" 
                : "border-white text-white hover:bg-white hover:text-brand-dark"
            )}
          >
            Book Now
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className={isScrolled ? "text-brand-dark" : "text-white"} /> : <Menu className={isScrolled ? "text-brand-dark" : "text-white"} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-white border-b border-black/5 p-6 flex flex-col gap-4 md:hidden animate-in fade-in slide-in-from-top-4">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-brand-dark text-lg font-serif"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <button 
            className="w-full py-3 bg-brand-dark text-white font-bold uppercase tracking-widest text-sm text-center"
            onClick={() => {
              setIsMobileMenuOpen(false);
              onBookNow();
            }}
          >
            Book Now
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
